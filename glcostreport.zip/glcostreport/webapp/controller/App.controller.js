sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("glcostrept.glcostreport.controller.App", {
        onInit: function() {
        }
      });
    }
  );
  