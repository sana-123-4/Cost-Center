sap.ui.define([
	"glcostrept/glcostreport/test/unit/controller/View.controller"
], function () {
	"use strict";
});
