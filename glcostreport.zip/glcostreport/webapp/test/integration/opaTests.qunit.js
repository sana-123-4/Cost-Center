/* global QUnit */

sap.ui.require(["glcostrept/glcostreport/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
