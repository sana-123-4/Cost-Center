sap.ui.define([
	"costcenterrpt/project2/test/unit/controller/View.controller"
], function () {
	"use strict";
});
