/* global QUnit */

sap.ui.require(["costcenterrpt/project2/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
